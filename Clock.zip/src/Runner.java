import sun.security.provider.certpath.Vertex;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Runner extends JFrame {

    private Calendar calendar;
    private String time;
    private String date;
    private SimpleDateFormat dateFormat;
    private SimpleDateFormat timeFormat;
    private JLabel timeLabel;
    private JLabel dateLabel;

    public Runner() {
        setLayout(new FlowLayout());
        setSize(220, 150);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.BLACK);

        timeLabel = new JLabel();
        dateLabel = new JLabel();
        dateFormat = new SimpleDateFormat("E  d.MMM.y");
        dateLabel.setFont(new Font("New System Regular", Font.PLAIN, 25));
        dateLabel.setForeground(new Color(0xFF00E7));
        dateLabel.setBackground(Color.BLACK);
        dateLabel.setOpaque(true);
        timeFormat = new SimpleDateFormat("kk:mm:ss");
        timeLabel.setFont(new Font("New System Regular", Font.PLAIN, 25));
        timeLabel.setForeground(new Color(0xFF00E7));
        timeLabel.setBackground(Color.BLACK);
        timeLabel.setOpaque(true);
        add(timeLabel);
        add(dateLabel);


        refresh();

    }

    public void refresh() {

        while (true) {
            time = timeFormat.format(Calendar.getInstance().getTime());
            timeLabel.setText(time);
            date = dateFormat.format(Calendar.getInstance().getTime());
            dateLabel.setText(date);
            try {
                Thread.sleep(1000);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }

    }
}